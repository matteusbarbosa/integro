var gulp = require('gulp');

gulp.task('default', function(){
//Tarefa padrão
console.log("Default task running...");
});
/*
gulp.task('default', function(){
//Tarefa padrão
console.log("Default task running...");
});
*//*
gulp.task('default', function(){
//Tarefa padrão
console.log("Default task running...");
});
*//*
gulp.task('default', function(){
//Tarefa padrão
console.log("Default task running...");
});
*//*
gulp.task('default', function(){
//Tarefa padrão
console.log("Default task running...");
});
*//*
gulp.task('default', function(){
//Tarefa padrão
console.log("Default task running...");
});
*/
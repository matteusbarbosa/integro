/*
	Tests done by vendor
*/
module.exports = function (db, cb) {

	db.load("./subscription", function (err) { 

		var User = db.define('user', {username: String, password: String, email : String} , {
			methods: {
				validPassword: function (pw) {
					return this.password == pw;
				}
			}
		});
		
		if (err) throw err;
		var Subscriptions = db.models.subscription;
		User.hasMany('subscriptions', Subscriptions);
	});

	return cb();

};
module.exports = function (db, cb) {

	var Discipline = db.define('discipline', {
		courseid: 'integer'
	} , {
		methods: {
		}
	});

	db.load("./content", function (err) {
		if (err) throw err;
		var Content = db.models.content;
		
	});

		Discipline.hasContents('content', Content);

	return cb();

};
module.exports = function (db, cb) {

	var Subscription = db.define('subscription', {
		userid: 'integer',
		instanceid: 'integer',
		classid: 'integer',
		metakind: String,
		timestart: 'integer',
		timeend: 'integer'
	} , {
		methods: {
			validPassword: function (pw) {
				return this.password == pw;
			}
		}
	});

	return cb();

};
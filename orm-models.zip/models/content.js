var utils = require('../utils');
module.exports = function (db, cb) {

	var Content = db.define('content', {
		title: String,
		metatitle: String,
		size: 'integer',
		url: 'text',
		timecreated: 'integer',
		timeupdated: 'integer',
		timedisabled: 'integer'
	} , {
		methods: {
			getMetatitle: function () {
				return utils.removeaccents(this.title);
			},
			validSize: function () {
				return (this.size < 100000);
			},
			validUrl: function () {
				return (this.url.indexOf('http://www.') > -1) && (this.url.indexOf('.com') > -1);
			},
			disable: function () {
				return this.timedisabled = Date.now();
			},
		}
	});
	
	return cb();
};
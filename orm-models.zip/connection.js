var express = require('express');
var app = express();
var orm = require('orm');

//orm
app.use(orm.express("mysql://root@localhost/integro", { define: function (db, models, next) {

	db.settings.set('instance.cache', false);

	db.load("./models/user", function (err) { if (err) throw err; });
	db.load("./models/content", function (err) { if (err) throw err; });
	//db.load("./models/course", function (err) { if (err) throw err; });
	//db.load("./models/discipline", function (err) { if (err) throw err; });
	//db.load("./models/examination", function (err) { if (err) throw err; });
	//db.load("./models/reinforcement", function (err) { if (err) throw err; });
	//db.load("./models/report", function (err) { if (err) throw err; });
	//db.load("./models/role", function (err) { if (err) throw err; });
	//db.load("./models/warning", function (err) { if (err) throw err; });


			// loaded!
			models.user = db.models.user;
			models.discipline = db.models.discipline;
			

			next();
		}}));

module.exports = app;